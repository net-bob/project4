package game;
import java.awt.Graphics;
public interface BorderGenerator {
	void generateBorder(Graphics brush);
}